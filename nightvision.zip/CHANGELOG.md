# 1.0.0

- Initial release

# 1.0.1

- Added BepInEx as dependency

# 1.1.0

- Hopefully fixed issues where mod did not work for some people
- Added optional config compatability with Diversity mod for total darkness
