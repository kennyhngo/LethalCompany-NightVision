# 2.1.0

- Added option to enable night vision outside
- Added configuration to adjust outdoor intensity
- Added option to not remove steam valve fog inside facility
- Flipped direction of CHANGELOG to have most recent version changes on top

# 2.0.0

- Fixed bug where night vision would not be enabled by default when configured to do so
- Reordered config file, you may need to delete the old one and generate a new one
- Night vision now works outside!
- Added option to toggle on and off fog
- The fog toggle may also be affect steam valve indoors, might add an option to disable that feature
- May possibly conflict with HDLethalCompany fog settings

# 1.1.3

- Added configurable to set night vision on or off when game loads.

# 1.1.2

- Somehow the wrong version got published, do NOT install this version

# 1.1.1

- Now doesn't toggle when typing in chat or terminal

# 1.1.0

- Hopefully fixed issues where mod did not work for some people
- Added optional config compatability with Diversity mod for total darkness

# 1.0.1

- Added BepInEx as dependency

# 1.0.0

- Initial release
