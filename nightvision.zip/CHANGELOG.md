# 1.0.0

- Initial release

# 1.0.1

- Added BepInEx as dependency
