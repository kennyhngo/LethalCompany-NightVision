# 1.0.0

- Initial release

# 1.0.1

- Added BepInEx as dependency

# 1.1.0

- Hopefully fixed issues where mod did not work for some people
- Added optional config compatability with Diversity mod for total darkness

# 1.1.1

- Now doesn't toggle when typing in chat or terminal

# 1.1.2

- Somehow the wrong version got published

# 1.1.3

- Added configurable to set night vision on or off when game loads.

# 2.0.0

- Fixed bug where night vision would not be enabled by default when configured to do so
- Reordered config file, you may need to delete the old one and generate a new one
- Night vision now works outside!
- Added option to toggle on and off fog
- The fog toggle may also be affect steam valve indoors, might add an option to disable that feature
- May possibly conflict with HDLethalCompany fog settings
