# ToggleableNightVision

An extension off of [this mod](https://thunderstore.io/c/lethal-company/p/zilli/NightVision/), adding
configuration to the intensity value and adding keybindings to toggle it on and off.

Now added compatability with the [Diversity](https://thunderstore.io/c/lethal-company/p/IntegrityChaos/Diversity/) mod.
